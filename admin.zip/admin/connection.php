<?php
$_SERVERNAME="localhost";
$_USERNAME="kpmbxbuade";
$_PASSWORD="zyBVYnf5Tm";
$_DBNAME="kpmbxbuade";
?>